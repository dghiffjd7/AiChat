module.exports = function (api) {
  api.logger.info('plugin started', api.plugin.id);

  api.storage.set('count', 1).then(async () => {
    const v = await api.storage.get('count');
    api.logger.info('storage.get', v);
  });

  api.events.on('message.before_send', (data) => {
    api.logger.info('before_send', data && data.content);
    if (data && typeof data.content === 'string') {
      data.content = data.content + ' [plugin]';
    }
    return data;
  });

  api.events.on('message.after_receive', (data) => {
    const preview = data && data.message && data.message.content
      ? String(data.message.content).slice(0, 40)
      : '';
    api.logger.info('after_receive', preview);
  });
};
